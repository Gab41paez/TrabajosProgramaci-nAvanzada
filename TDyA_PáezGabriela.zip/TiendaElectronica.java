import java.util.ArrayList;
//CLASE PRINCIPAL
public class TiendaElectronica {
    public static void main(String[] args) {
        ArrayList<ProductoElectronico> productos = new ArrayList<>();//Una lista llamada productos se instancia.
        
        // Crear objetos de cada clase hija y agregarlos al ArrayList
        productos.add(new Celular("iPhone", 999.99, 12, "iPhone 12"));//Nombre - Precio - Garantia - Modelo
        productos.add(new Celular("Samsung", 123.99, 24, "Galaxy A32"));
        productos.add(new Computadora("Dell", 1499.99, 36, "Inspiron"));
        productos.add(new Computadora("Samsung", 1299.99, 24, "S20"));
        
        // Recorrer la lista y ejecutar los métodos de cada objeto
        for (ProductoElectronico producto : productos) {
            System.out.println("Nombre: " + producto.getNombre());
            System.out.println("Precio: " + producto.getPrecio());
            System.out.println("Garantía: " + producto.getGarantia());
            producto.cargar(3); //Se inicializa la carga inicial con 3 horas
            System.out.println(" ");
        }
    }
}