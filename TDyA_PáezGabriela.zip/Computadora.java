class Computadora extends ProductoElectronico {//Clase computadora heredada de Producto electronico
    private String marca;//Atribiro de la case

    public Computadora(String nombre, double precio, int garantia, String marca) {
        super(nombre, precio, garantia);
        this.marca = marca;
    }
//Get
    public String getMarca() {
        return marca;
    }
  @Override
    public void cargar(double cargaInicial) {
        System.out.println("Cargando la computadora " + getMarca() + " con una carga inicial de " + cargaInicial + " horas.");//Se presentan los datos de la carga de la computadora
    }
}