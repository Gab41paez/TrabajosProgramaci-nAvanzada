class Celular extends ProductoElectronico {//Clase celular heredada de Producto electronico
    private String modelo;
//Constructor
    public Celular(String nombre, double precio, int garantia, String modelo) {
        super(nombre, precio, garantia);
        this.modelo = modelo;
    }
//Get
    public String getModelo() {
        return modelo;
    }
    public void setModelo(){
      this.modelo = modelo;
    }
    @Override//Se sobreescribe el método abstracto
    public void cargar(double cargaInicial) {
        System.out.println("Cargando el celular " + getModelo() + " con una carga inicial de " + cargaInicial + " horas.");//Se presentan los datos de la carga del celular
    }
}