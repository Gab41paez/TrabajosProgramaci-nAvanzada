abstract class ProductoElectronico {//Clase plantilla para los praductos
    private String nombre;
    private double precio;
    private int garantia;
//Constructor
    public ProductoElectronico(String nombre, double precio, int garantia) {//SE inicializan variables
        this.nombre = nombre;
        this.precio = precio;
        this.garantia = garantia;
    }
  //Getters and setters
    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getGarantia() {
        return garantia;
    }
//Método abstracto
    public abstract void cargar(double cargaInicial);
}